const sharp = require('sharp');
const axios = require('axios');
const { formatMoney } = require('./helpers');

function escapeXml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

async function urlToBase64(url, size) {
  if (!url) return null;
  try {
    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 6000 });
    const buf = size
      ? await sharp(Buffer.from(res.data)).resize(size, size, { fit: 'cover' }).png().toBuffer()
      : await sharp(Buffer.from(res.data)).png().toBuffer();
    return `data:image/png;base64,${buf.toString('base64')}`;
  } catch (_) { return null; }
}

async function getCircularAvatarBuffer(avatarUrl, size) {
  if (!avatarUrl) return null;
  try {
    const res = await axios.get(avatarUrl, { responseType: 'arraybuffer', timeout: 5000 });
    const half = Math.floor(size / 2);
    const mask = Buffer.from(`<svg width="${size}" height="${size}"><circle cx="${half}" cy="${half}" r="${half}" fill="white"/></svg>`);
    return await sharp(Buffer.from(res.data))
      .resize(size, size, { fit: 'cover' })
      .composite([{ input: mask, blend: 'dest-in' }])
      .png().toBuffer();
  } catch (_) { return null; }
}

async function generateProfileCard(user, avatarUrl) {
  try {
    const W = 800, H = 800;
    const effectiveAvatarUrl = user.customPpUrl || avatarUrl;
    const avatarBase64 = await urlToBase64(effectiveAvatarUrl, 220);

    let bgLayer = `<rect width="${W}" height="${H}" fill="url(#bgGrad)"/>`;
    if (user.bgUrl) {
      const bgBase64 = await urlToBase64(user.bgUrl, null);
      if (bgBase64) {
        bgLayer = `
          <image href="${bgBase64}" x="0" y="0" width="${W}" height="${H}" preserveAspectRatio="xMidYMid slice"/>
          <rect width="${W}" height="${H}" fill="#00000088"/>`;
      }
    }

    const bankFormatted = formatMoney(user.bank || 0);
    const walletFormatted = formatMoney(user.wallet || 0);
    const xpCurrent = user.xp || 0;
    const xpMax = (user.level || 1) * 100;
    const xpBarFull = 300;
    const xpBarFill = Math.max(8, Math.floor(xpBarFull * Math.min(xpCurrent / xpMax, 1)));
    const rank = user.rank || '?';
    const level = user.level || 1;
    const name = escapeXml((user.name || 'Unknown').toUpperCase());
    const community = escapeXml(user.community || 'KONOSUBA');
    const avatarImg = avatarBase64
      ? `<image href="${avatarBase64}" x="290" y="200" width="220" height="220" clip-path="url(#avatarClip)" preserveAspectRatio="xMidYMid slice"/>`
      : `<circle cx="400" cy="310" r="110" fill="#2a1a4e"/>`;

    const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${W}" height="${H}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#1a0535"/>
      <stop offset="50%" style="stop-color:#0d0220"/>
      <stop offset="100%" style="stop-color:#060115"/>
    </linearGradient>
    <linearGradient id="xpGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" style="stop-color:#7040c0"/>
      <stop offset="100%" style="stop-color:#c080ff"/>
    </linearGradient>
    <radialGradient id="glowGrad" cx="50%" cy="50%" r="50%">
      <stop offset="0%" style="stop-color:#8040d0;stop-opacity:0.3"/>
      <stop offset="100%" style="stop-color:#8040d0;stop-opacity:0"/>
    </radialGradient>
    <clipPath id="avatarClip"><circle cx="400" cy="310" r="110"/></clipPath>
    <filter id="textGlow">
      <feGaussianBlur in="SourceGraphic" stdDeviation="2" result="blur"/>
      <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
    <filter id="softGlow">
      <feGaussianBlur in="SourceGraphic" stdDeviation="4" result="blur"/>
      <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>

  ${bgLayer}
  <line x1="0" y1="133" x2="${W}" y2="133" stroke="#ffffff06" stroke-width="1"/>
  <line x1="0" y1="266" x2="${W}" y2="266" stroke="#ffffff06" stroke-width="1"/>
  <line x1="0" y1="400" x2="${W}" y2="400" stroke="#ffffff06" stroke-width="1"/>
  <line x1="0" y1="533" x2="${W}" y2="533" stroke="#ffffff06" stroke-width="1"/>
  <line x1="0" y1="666" x2="${W}" y2="666" stroke="#ffffff06" stroke-width="1"/>
  <line x1="133" y1="0" x2="133" y2="${H}" stroke="#ffffff06" stroke-width="1"/>
  <line x1="266" y1="0" x2="266" y2="${H}" stroke="#ffffff06" stroke-width="1"/>
  <line x1="400" y1="0" x2="400" y2="${H}" stroke="#ffffff06" stroke-width="1"/>
  <line x1="533" y1="0" x2="533" y2="${H}" stroke="#ffffff06" stroke-width="1"/>
  <line x1="666" y1="0" x2="666" y2="${H}" stroke="#ffffff06" stroke-width="1"/>
  <circle cx="400" cy="310" r="200" fill="url(#glowGrad)"/>
  <text x="30" y="45" font-family="Arial,sans-serif" font-size="22" font-weight="bold" fill="white">Bank: ${bankFormatted}</text>
  <text x="30" y="78" font-family="Arial,sans-serif" font-size="22" font-weight="bold" fill="white">Wallet: ${walletFormatted}</text>
  <ellipse cx="320" cy="155" rx="42" ry="88" fill="#9060c8" transform="rotate(-12 320 155)"/>
  <ellipse cx="320" cy="155" rx="26" ry="62" fill="#e0c8ff" transform="rotate(-12 320 155)"/>
  <rect x="290" y="195" width="30" height="20" rx="5" fill="#9060c8"/>
  <ellipse cx="480" cy="155" rx="42" ry="88" fill="#9060c8" transform="rotate(12 480 155)"/>
  <ellipse cx="480" cy="155" rx="26" ry="62" fill="#e0c8ff" transform="rotate(12 480 155)"/>
  <rect x="480" y="195" width="30" height="20" rx="5" fill="#9060c8"/>
  <ellipse cx="400" cy="300" rx="175" ry="155" fill="#7840b8"/>
  <ellipse cx="400" cy="300" rx="158" ry="140" fill="#9060d0"/>
  <ellipse cx="400" cy="300" rx="136" ry="122" fill="#d8c0f8"/>
  ${avatarImg}
  <circle cx="400" cy="310" r="113" fill="none" stroke="#6030a8" stroke-width="4" opacity="0.8"/>
  <circle cx="400" cy="435" r="20" fill="#f0c030" filter="url(#softGlow)"/>
  <circle cx="400" cy="435" r="20" fill="none" stroke="#c09010" stroke-width="2"/>
  <ellipse cx="400" cy="428" rx="5" ry="4" fill="#a07010"/>
  <line x1="397" y1="432" x2="403" y2="432" stroke="#a07010" stroke-width="1.5"/>
  <text x="400" y="502" font-family="Arial Black,Impact,sans-serif" font-size="52" font-weight="900" text-anchor="middle" fill="white" filter="url(#textGlow)" letter-spacing="3">${name}</text>
  <text x="400" y="538" font-family="Arial,sans-serif" font-size="19" text-anchor="middle" fill="#cc99ff" font-style="italic">(${escapeXml(user.rpg?.class || 'Adventurer')})</text>
  <text x="400" y="576" font-family="Arial,sans-serif" font-size="24" font-weight="bold" text-anchor="middle" fill="#e0ccff">Rank #${rank} Level ${level}</text>
  <rect x="250" y="592" width="${xpBarFull}" height="28" rx="14" fill="#ffffff18"/>
  <rect x="250" y="592" width="${xpBarFill}" height="28" rx="14" fill="url(#xpGrad)"/>
  <rect x="255" y="596" width="${Math.max(0, xpBarFill - 10)}" height="8" rx="4" fill="#ffffff30"/>
  <text x="400" y="612" font-family="Arial,sans-serif" font-size="15" text-anchor="middle" fill="white">${xpCurrent} / ${xpMax} XP</text>
  <line x1="120" y1="650" x2="${W - 120}" y2="650" stroke="#ffffff28" stroke-width="1"/>
  <text x="400" y="690" font-family="Arial,sans-serif" font-size="22" text-anchor="middle" fill="#ffffff60" letter-spacing="2">${community} - Family</text>
</svg>`;

    return await sharp(Buffer.from(svg)).png().toBuffer();
  } catch (err) {
    console.error('Profile card error:', err.message);
    return null;
  }
}

async function generateBalanceCard(user, avatarUrl) {
  try {
    const W = 900, H = 480;
    const effectiveAvatarUrl = user.customPpUrl || avatarUrl;
    const avatarBase64 = await urlToBase64(effectiveAvatarUrl, 110);

    const walletFormatted = formatMoney(user.wallet || 0);
    const bankFormatted   = formatMoney(user.bank || 0);
    const maxCap          = formatMoney(user.bankLimit || 0);
    const total           = formatMoney((user.wallet || 0) + (user.bank || 0));
    const name            = escapeXml((user.name || 'Unknown').toUpperCase());
    const accNo           = escapeXml(user.accNo || '------');
    const memberSince     = user.joinedAt ? new Date(user.joinedAt).getFullYear() : '----';

    let bgLayer = `<rect width="${W}" height="${H}" fill="url(#bgGrad)"/>`;
    if (user.bgUrl) {
      const bgBase64 = await urlToBase64(user.bgUrl, null);
      if (bgBase64) {
        bgLayer = `
          <image href="${bgBase64}" x="0" y="0" width="${W}" height="${H}" preserveAspectRatio="xMidYMid slice"/>
          <rect width="${W}" height="${H}" fill="#00000099"/>`;
      }
    }

    const avatarImg = avatarBase64
      ? `<image href="${avatarBase64}" x="54" y="130" width="110" height="110" clip-path="url(#avaClip)" preserveAspectRatio="xMidYMid slice"/>`
      : `<circle cx="109" cy="185" r="55" fill="#1a2a4a"/>`;

    const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${W}" height="${H}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#0a1628"/>
      <stop offset="60%" style="stop-color:#0f1e3a"/>
      <stop offset="100%" style="stop-color:#0d1a30"/>
    </linearGradient>
    <linearGradient id="goldBar" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" style="stop-color:#c8960a"/>
      <stop offset="50%" style="stop-color:#f5d060"/>
      <stop offset="100%" style="stop-color:#c8960a"/>
    </linearGradient>
    <linearGradient id="totalGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" style="stop-color:#f5d060"/>
      <stop offset="100%" style="stop-color:#ffa040"/>
    </linearGradient>
    <clipPath id="avaClip"><circle cx="109" cy="185" r="55"/></clipPath>
    <filter id="glow">
      <feGaussianBlur in="SourceGraphic" stdDeviation="3" result="b"/>
      <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>

  ${bgLayer}

  <!-- Diagonal decorative lines -->
  <line x1="0" y1="0" x2="900" y2="480" stroke="#ffffff04" stroke-width="80"/>
  <line x1="-100" y1="0" x2="800" y2="480" stroke="#ffffff03" stroke-width="60"/>
  <line x1="100" y1="0" x2="1000" y2="480" stroke="#ffffff03" stroke-width="60"/>

  <!-- Gold accent bar top -->
  <rect x="0" y="0" width="${W}" height="6" fill="url(#goldBar)"/>

  <!-- Gold accent bar bottom -->
  <rect x="0" y="${H - 6}" width="${W}" height="6" fill="url(#goldBar)"/>

  <!-- Top header area -->
  <!-- Bank building icon (columns) -->
  <rect x="36" y="22" width="56" height="5" rx="2" fill="#f5d060"/>
  <rect x="40" y="27" width="6" height="30" rx="1" fill="#f5d060"/>
  <rect x="50" y="27" width="6" height="30" rx="1" fill="#f5d060"/>
  <rect x="60" y="27" width="6" height="30" rx="1" fill="#f5d060"/>
  <rect x="70" y="27" width="6" height="30" rx="1" fill="#f5d060"/>
  <rect x="80" y="27" width="6" height="30" rx="1" fill="#f5d060"/>
  <rect x="36" y="57" width="56" height="5" rx="2" fill="#f5d060"/>
  <rect x="30" y="18" width="68" height="8" rx="2" fill="#f5d060"/>
  <polygon points="64,10 100,18 28,18" fill="#f5d060"/>

  <!-- Bank name -->
  <text x="106" y="46" font-family="Arial Black,sans-serif" font-size="22" font-weight="900" fill="#f5d060" letter-spacing="3" filter="url(#glow)">KONOSUBA BANK</text>
  <text x="106" y="66" font-family="Arial,sans-serif" font-size="12" fill="#c8960a" letter-spacing="2">OFFICIAL ACCOUNT STATEMENT</text>

  <!-- Divider -->
  <rect x="30" y="80" width="${W - 60}" height="1" fill="url(#goldBar)" opacity="0.6"/>

  <!-- Avatar circle border -->
  <circle cx="109" cy="185" r="60" fill="#0a1628" stroke="#f5d060" stroke-width="2.5"/>
  ${avatarImg}

  <!-- Account holder info -->
  <text x="200" y="145" font-family="Arial Black,sans-serif" font-size="26" font-weight="900" fill="white" letter-spacing="2">${name}</text>
  <text x="200" y="172" font-family="Arial,sans-serif" font-size="14" fill="#a0b8d8" letter-spacing="1">ACCOUNT HOLDER</text>
  <rect x="200" y="182" width="480" height="1" fill="#ffffff18"/>
  <text x="200" y="205" font-family="Arial,sans-serif" font-size="13" fill="#8090a8">ACCOUNT NO.</text>
  <text x="310" y="205" font-family="'Courier New',monospace" font-size="13" fill="#f5d060" letter-spacing="2">${accNo}</text>
  <text x="200" y="228" font-family="Arial,sans-serif" font-size="13" fill="#8090a8">MEMBER SINCE</text>
  <text x="310" y="228" font-family="Arial,sans-serif" font-size="13" fill="#f5d060">${memberSince}</text>

  <!-- Divider -->
  <rect x="30" y="260" width="${W - 60}" height="1" fill="#ffffff18"/>

  <!-- Balance rows -->
  <!-- Wallet -->
  <text x="50" y="300" font-family="Arial,sans-serif" font-size="15" fill="#8090a8">💸  WALLET</text>
  <text x="${W - 50}" y="300" font-family="Arial,sans-serif" font-size="16" font-weight="bold" fill="white" text-anchor="end">${walletFormatted}</text>

  <rect x="30" y="312" width="${W - 60}" height="1" fill="#ffffff0a"/>

  <!-- Bank -->
  <text x="50" y="345" font-family="Arial,sans-serif" font-size="15" fill="#8090a8">🏦  BANK BALANCE</text>
  <text x="${W - 50}" y="345" font-family="Arial,sans-serif" font-size="16" font-weight="bold" fill="white" text-anchor="end">${bankFormatted}</text>

  <rect x="30" y="357" width="${W - 60}" height="1" fill="#ffffff0a"/>

  <!-- Max capacity -->
  <text x="50" y="390" font-family="Arial,sans-serif" font-size="15" fill="#8090a8">🌌  MAX CAPACITY</text>
  <text x="${W - 50}" y="390" font-family="Arial,sans-serif" font-size="16" fill="#6080a0" text-anchor="end">${maxCap}</text>

  <!-- Total divider -->
  <rect x="30" y="408" width="${W - 60}" height="2" fill="url(#goldBar)" opacity="0.5"/>

  <!-- Total -->
  <text x="50" y="445" font-family="Arial Black,sans-serif" font-size="17" font-weight="900" fill="#f5d060" letter-spacing="1">💎  NET WORTH</text>
  <text x="${W - 50}" y="445" font-family="Arial Black,sans-serif" font-size="20" font-weight="900" fill="url(#totalGrad)" text-anchor="end" filter="url(#glow)">${total}</text>

</svg>`;

    return await sharp(Buffer.from(svg)).png().toBuffer();
  } catch (err) {
    console.error('Balance card error:', err.message);
    return null;
  }
}

module.exports = { generateProfileCard, generateBalanceCard, getCircularAvatarBuffer };
