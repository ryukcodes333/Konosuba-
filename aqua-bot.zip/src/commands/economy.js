const User = require('../models/User');
const { formatMs, formatMoney, isOwner, parseAmount, randomInt } = require('../utils/helpers');
const { generateBalanceCard } = require('../utils/imageGen');
const config = require('../config');

const SHOP_ITEMS = [
  { name: 'Fishing Rod', price: 500, desc: 'Used for fishing' },
  { name: 'Shovel', price: 300, desc: 'Used for digging' },
  { name: 'Lucky Charm', price: 2000, desc: 'Boosts luck slightly' },
  { name: 'Bank Card', price: 5000, desc: 'Increases bank limit' },
  { name: 'Poké Ball', price: 200, desc: 'Catch Pokémon' },
  { name: 'Great Ball', price: 500, desc: 'Better catch rate' },
  { name: 'Ultra Ball', price: 1200, desc: 'Even better catch rate' },
  { name: 'Health Potion', price: 150, desc: 'Restore HP in RPG' },
  { name: 'XP Booster', price: 3000, desc: 'Double XP for 1 hour' },
  { name: 'Pet Egg', price: 4000, desc: 'Hatch a pet!' },
];

async function getOrCreateUser(jid, name) {
  let user = await User.findOne({ jid });
  if (!user) {
    user = new User({ jid, name: name || jid.split('@')[0] });
    await user.save();
  }
  return user;
}

function cdCheck(user, command, dest, sock, message) {
  if (user.isOnCooldown(command)) {
    const left = user.getCooldownLeft(command);
    return sock.sendMessage(dest, {
      text: `⏳ You're on cooldown for \`${command}\`! Try again in *${formatMs(left)}*`,
    }, { quoted: message });
  }
  return null;
}

async function handleEconomy(sock, message, command, args, sender, isGroup, groupJid) {
  const dest = isGroup ? groupJid : sender;
  const user = await getOrCreateUser(sender, message.pushName);
  if (user.banned) {
    await sock.sendMessage(dest, { text: '*🚫 Access Denied*' }, { quoted: message });
    return true;
  }

  if (command === 'balance' || command === 'bal') {
    let avatarUrl = null;
    try { avatarUrl = await sock.profilePictureUrl(sender, 'image'); } catch (_) {}

    const card = await generateBalanceCard(user, avatarUrl);
    if (card) {
      await sock.sendMessage(dest, { image: card, caption: '' }, { quoted: message });
    } else {
      const displayName = user.name || message.pushName || sender.split('@')[0];
      await sock.sendMessage(dest, {
        text: `━━━━━━━━━━━━━━━━━━━\n💰 *ACCOUNT BALANCE*\n━━━━━━━━━━━━━━━━━━━\n\n👤 *${displayName}*\n\n💸 Wallet:  [ ${formatMoney(user.wallet)} ]\n🏦 Bank:    [ ${formatMoney(user.bank)} ]\n🌌 Max Capacity: [ ${formatMoney(user.bankLimit)} ]\n\n━━━━━━━━━━━━━━━━━━━\n💎 Total:  [ ${formatMoney(user.wallet + user.bank)} ]`,
      }, { quoted: message });
    }
    return true;
  }

  if (command === 'wallet') {
    await sock.sendMessage(dest, {
      text: `💸 *Wallet Balance*\n\n👤 ${user.name}\n💸 Wallet: ${formatMoney(user.wallet)}`,
    }, { quoted: message });
    return true;
  }

  if (command === 'bank') {
    await sock.sendMessage(dest, {
      text: `🏦 *Bank Balance*\n\n👤 ${user.name}\n🏦 Bank: ${formatMoney(user.bank)}\n🌌 Bank Limit: ${formatMoney(user.bankLimit)}`,
    }, { quoted: message });
    return true;
  }

  if (command === 'deposit' || command === 'dep') {
    const amount = args[0] === 'all' ? user.wallet : parseAmount(args[0]);
    if (!amount) {
      await sock.sendMessage(dest, { text: '❌ Usage: `.deposit <amount>` or `.deposit all`' }, { quoted: message });
      return true;
    }
    if (amount > user.wallet) {
      await sock.sendMessage(dest, { text: `❌ You only have ${formatMoney(user.wallet)} in your wallet.` }, { quoted: message });
      return true;
    }
    if (user.bank + amount > user.bankLimit) {
      await sock.sendMessage(dest, { text: `❌ Bank limit reached! Max: ${formatMoney(user.bankLimit)}` }, { quoted: message });
      return true;
    }
    user.wallet -= amount;
    user.bank += amount;
    await user.save();
    try {
      const fs = require('fs');
      const path = require('path');
      const imgPath = path.join(__dirname, '../assets/deposit.jpg');
      const imgBuffer = fs.readFileSync(imgPath);
      await sock.sendMessage(dest, {
        image: imgBuffer,
        caption: `✅ *Deposited* ${formatMoney(amount)} to your bank!\n🏦 Bank: ${formatMoney(user.bank)}\n💸 Wallet: ${formatMoney(user.wallet)}`,
      }, { quoted: message });
    } catch (_) {
      await sock.sendMessage(dest, {
        text: `✅ Deposited ${formatMoney(amount)} to your bank!\n🏦 Bank: ${formatMoney(user.bank)}\n💸 Wallet: ${formatMoney(user.wallet)}`,
      }, { quoted: message });
    }
    return true;
  }

  if (command === 'withdraw' || command === 'with') {
    const amount = args[0] === 'all' ? user.bank : parseAmount(args[0]);
    if (!amount) {
      await sock.sendMessage(dest, { text: '❌ Usage: `.withdraw <amount>` or `.withdraw all`' }, { quoted: message });
      return true;
    }
    if (amount > user.bank) {
      await sock.sendMessage(dest, { text: `❌ You only have ${formatMoney(user.bank)} in your bank.` }, { quoted: message });
      return true;
    }
    user.bank -= amount;
    user.wallet += amount;
    await user.save();
    try {
      const fs = require('fs');
      const path = require('path');
      const imgPath = path.join(__dirname, '../assets/withdraw.jpg');
      const imgBuffer = fs.readFileSync(imgPath);
      await sock.sendMessage(dest, {
        image: imgBuffer,
        caption: `✅ *Withdrew* ${formatMoney(amount)} from bank!\n💸 Wallet: ${formatMoney(user.wallet)}\n🏦 Bank: ${formatMoney(user.bank)}`,
      }, { quoted: message });
    } catch (_) {
      await sock.sendMessage(dest, {
        text: `✅ Withdrew ${formatMoney(amount)} from bank!\n💸 Wallet: ${formatMoney(user.wallet)}\n🏦 Bank: ${formatMoney(user.bank)}`,
      }, { quoted: message });
    }
    return true;
  }

  if (command === 'withdrawall') {
    const amount = user.bank;
    if (amount <= 0) {
      await sock.sendMessage(dest, { text: '❌ Your bank is empty.' }, { quoted: message });
      return true;
    }
    user.wallet += amount;
    user.bank = 0;
    await user.save();
    await sock.sendMessage(dest, {
      text: `✅ Withdrew all ${formatMoney(amount)} from bank!`,
    }, { quoted: message });
    return true;
  }

  if (command === 'pay') {
    const mentions = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const quotedSender = message.message?.extendedTextMessage?.contextInfo?.participant;
    const target = quotedSender || mentions[0];
    const amount = parseAmount(args[mentions.length > 0 ? 1 : 0]);
    if (!target || !amount) {
      await sock.sendMessage(dest, { text: '❌ Usage: `.pay @user <amount>`' }, { quoted: message });
      return true;
    }
    if (target === sender) {
      await sock.sendMessage(dest, { text: '❌ You cannot pay yourself!' }, { quoted: message });
      return true;
    }
    if (amount > user.wallet) {
      await sock.sendMessage(dest, { text: `❌ Insufficient wallet balance. You have ${formatMoney(user.wallet)}.` }, { quoted: message });
      return true;
    }
    const targetUser = await getOrCreateUser(target);
    user.wallet -= amount;
    targetUser.wallet += amount;
    await user.save();
    await targetUser.save();
    await sock.sendMessage(dest, {
      text: `💸 Sent ${formatMoney(amount)} to @${target.split('@')[0]}!`,
      mentions: [target],
    }, { quoted: message });
    return true;
  }

  if (command === 'daily') {
    const cdLeft = await cdCheck(user, 'daily', dest, sock, message);
    if (cdLeft) return true;
    const amount = config.ECONOMY.DAILY_AMOUNT();
    user.wallet += amount;
    user.streak = (user.streak || 0) + 1;
    user.setCooldown('daily');
    await user.save();
    await sock.sendMessage(dest, {
      text: `✅ *Daily Reward!*\n💰 You received ${formatMoney(amount)}!\n🔥 Streak: ${user.streak} days\n💸 Wallet: ${formatMoney(user.wallet)}`,
    }, { quoted: message });
    return true;
  }

  if (command === 'weekly') {
    const cdLeft = await cdCheck(user, 'weekly', dest, sock, message);
    if (cdLeft) return true;
    const amount = config.ECONOMY.WEEKLY_AMOUNT();
    user.wallet += amount;
    user.setCooldown('weekly');
    await user.save();
    await sock.sendMessage(dest, {
      text: `✅ *Weekly Reward!*\n💰 You received ${formatMoney(amount)}!\n💸 Wallet: ${formatMoney(user.wallet)}`,
    }, { quoted: message });
    return true;
  }

  if (command === 'monthly') {
    const cdLeft = await cdCheck(user, 'monthly', dest, sock, message);
    if (cdLeft) return true;
    const amount = config.ECONOMY.MONTHLY_AMOUNT();
    user.wallet += amount;
    user.setCooldown('monthly');
    await user.save();
    await sock.sendMessage(dest, {
      text: `✅ *Monthly Reward!*\n💰 You received ${formatMoney(amount)}!\n💸 Wallet: ${formatMoney(user.wallet)}`,
    }, { quoted: message });
    return true;
  }

  if (command === 'work') {
    const cdLeft = await cdCheck(user, 'work', dest, sock, message);
    if (cdLeft) return true;
    const jobs = ['programmer', 'chef', 'driver', 'teacher', 'nurse', 'farmer', 'mechanic', 'artist'];
    const job = jobs[Math.floor(Math.random() * jobs.length)];
    const amount = config.ECONOMY.WORK_AMOUNT();
    user.wallet += amount;
    user.setCooldown('work');
    const leveled = user.addXp(10);
    await user.save();
    await sock.sendMessage(dest, {
      text: `💼 You worked as a *${job}* and earned ${formatMoney(amount)}!${leveled ? '\n🆙 *LEVEL UP!* You are now level ' + user.level : ''}\n💸 Wallet: ${formatMoney(user.wallet)}`,
    }, { quoted: message });
    return true;
  }

  if (command === 'beg') {
    const cdLeft = await cdCheck(user, 'beg', dest, sock, message);
    if (cdLeft) return true;
    const amount = config.ECONOMY.BEG_AMOUNT();
    user.wallet += amount;
    user.setCooldown('beg');
    await user.save();
    const responses = ['A kind stranger gave you', 'Someone felt pity and gave you', 'A passerby tossed you'];
    await sock.sendMessage(dest, {
      text: `🙏 ${responses[randomInt(0, responses.length - 1)]} ${formatMoney(amount)}!\n💸 Wallet: ${formatMoney(user.wallet)}`,
    }, { quoted: message });
    return true;
  }

  if (command === 'crime') {
    const cdLeft = await cdCheck(user, 'crime', dest, sock, message);
    if (cdLeft) return true;
    const success = Math.random() < 0.5;
    const amount = randomInt(100, 500);
    user.setCooldown('crime');
    if (success) {
      user.wallet += amount;
      await user.save();
      const crimes = ['robbed a store', 'pickpocketed someone', 'hacked a bank account', 'sold counterfeit goods'];
      await sock.sendMessage(dest, {
        text: `🦹 You ${crimes[randomInt(0, crimes.length - 1)]} and got away with ${formatMoney(amount)}!\n💸 Wallet: ${formatMoney(user.wallet)}`,
      }, { quoted: message });
    } else {
      const fine = randomInt(50, 200);
      user.wallet = Math.max(0, user.wallet - fine);
      await user.save();
      await sock.sendMessage(dest, {
        text: `🚔 You got caught! Paid a fine of ${formatMoney(fine)}.\n💸 Wallet: ${formatMoney(user.wallet)}`,
      }, { quoted: message });
    }
    return true;
  }

  if (command === 'rob') {
    const cdLeft = await cdCheck(user, 'rob', dest, sock, message);
    if (cdLeft) return true;
    const mentions = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const quotedSender = message.message?.extendedTextMessage?.contextInfo?.participant;
    const target = quotedSender || mentions[0];
    if (!target) {
      await sock.sendMessage(dest, { text: '❌ Mention or reply to a user to rob!' }, { quoted: message });
      return true;
    }
    if (target === sender) {
      await sock.sendMessage(dest, { text: '❌ You cannot rob yourself!' }, { quoted: message });
      return true;
    }
    const targetUser = await getOrCreateUser(target);
    user.setCooldown('rob');
    const success = Math.random() < 0.4;
    if (success && targetUser.wallet > 0) {
      const amount = Math.min(randomInt(50, 300), targetUser.wallet);
      targetUser.wallet -= amount;
      user.wallet += amount;
      await user.save();
      await targetUser.save();
      await sock.sendMessage(dest, {
        text: `🦹 You robbed @${target.split('@')[0]} and stole ${formatMoney(amount)}!\n💸 Wallet: ${formatMoney(user.wallet)}`,
        mentions: [target],
      }, { quoted: message });
    } else {
      const fine = randomInt(50, 150);
      user.wallet = Math.max(0, user.wallet - fine);
      await user.save();
      await sock.sendMessage(dest, {
        text: `🚔 You failed to rob @${target.split('@')[0]} and paid ${formatMoney(fine)} as a fine!`,
        mentions: [target],
      }, { quoted: message });
    }
    return true;
  }

  if (command === 'heist') {
    const cdLeft = await cdCheck(user, 'heist', dest, sock, message);
    if (cdLeft) return true;
    const success = Math.random() < 0.35;
    const amount = randomInt(500, 3000);
    user.setCooldown('heist');
    if (success) {
      user.wallet += amount;
      await user.save();
      await sock.sendMessage(dest, {
        text: `🏦💥 *HEIST SUCCESS!*\nYour crew robbed a vault and got away with ${formatMoney(amount)}!\n💸 Wallet: ${formatMoney(user.wallet)}`,
      }, { quoted: message });
    } else {
      const loss = randomInt(200, 500);
      user.wallet = Math.max(0, user.wallet - loss);
      await user.save();
      await sock.sendMessage(dest, {
        text: `🚔 *HEIST FAILED!*\nThe police caught you! Lost ${formatMoney(loss)} in fines.\n💸 Wallet: ${formatMoney(user.wallet)}`,
      }, { quoted: message });
    }
    return true;
  }

  if (command === 'fish') {
    const cdLeft = await cdCheck(user, 'fish', dest, sock, message);
    if (cdLeft) return true;
    const hasRod = user.inventory.some(i => i.item === 'Fishing Rod');
    if (!hasRod) {
      await sock.sendMessage(dest, { text: '🎣 You need a *Fishing Rod*! Buy one at `.market`' }, { quoted: message });
      return true;
    }
    const caught = Math.random() < 0.7;
    user.setCooldown('fish');
    if (caught) {
      const fishes = ['🐟 Common Fish', '🐠 Tropical Fish', '🐡 Pufferfish', '🦐 Shrimp', '🦑 Squid', '🐙 Octopus', '💎 Diamond Fish'];
      const weights = [40, 25, 15, 10, 5, 3, 2];
      let roll = Math.random() * 100;
      let idx = 0;
      for (let i = 0; i < weights.length; i++) {
        if (roll < weights[i]) { idx = i; break; }
        roll -= weights[i];
      }
      const fish = fishes[idx];
      const maxAmount = idx === 6 ? config.ECONOMY.FISH_MAX : randomInt(10, 300);
      const amount = Math.min(maxAmount, config.ECONOMY.FISH_MAX);
      user.wallet += amount;
      await user.save();
      await sock.sendMessage(dest, {
        text: `🎣 You caught a ${fish} and sold it for ${formatMoney(amount)}!\n💸 Wallet: ${formatMoney(user.wallet)}`,
      }, { quoted: message });
    } else {
      await sock.sendMessage(dest, { text: '🎣 No luck this time... the fish got away!' }, { quoted: message });
    }
    return true;
  }

  if (command === 'dig') {
    const cdLeft = await cdCheck(user, 'dig', dest, sock, message);
    if (cdLeft) return true;
    const hasShovel = user.inventory.some(i => i.item === 'Shovel');
    if (!hasShovel) {
      await sock.sendMessage(dest, { text: '⛏️ You need a *Shovel*! Buy one at `.market`' }, { quoted: message });
      return true;
    }
    const found = Math.random() < 0.6;
    user.setCooldown('dig');
    if (found) {
      const items = ['💰 Coins', '💎 Gem', '🏺 Ancient Artifact', '🪨 Common Rock', '💍 Old Ring', '💰 Large Treasure'];
      const weights = [40, 20, 10, 15, 10, 5];
      let roll = Math.random() * 100;
      let idx = 0;
      for (let i = 0; i < weights.length; i++) {
        if (roll < weights[i]) { idx = i; break; }
        roll -= weights[i];
      }
      const item = items[idx];
      const maxAmount = idx === 5 ? config.ECONOMY.DIG_MAX : randomInt(5, 200);
      const amount = Math.min(maxAmount, config.ECONOMY.DIG_MAX);
      user.wallet += amount;
      await user.save();
      await sock.sendMessage(dest, {
        text: `⛏️ You dug up a ${item} worth ${formatMoney(amount)}!\n💸 Wallet: ${formatMoney(user.wallet)}`,
      }, { quoted: message });
    } else {
      await sock.sendMessage(dest, { text: '⛏️ You dug for a while but found nothing!' }, { quoted: message });
    }
    return true;
  }

  if (command === 'market') {
    const list = SHOP_ITEMS.map((i, idx) => `*${idx + 1}.* ${i.name} — ${formatMoney(i.price)}\n   _${i.desc}_`).join('\n\n');
    await sock.sendMessage(dest, {
      text: `🛒 *AQUA\'S MARKET*\n\n${list}\n\n> Use \`.buy <item name>\` to purchase.`,
    }, { quoted: message });
    return true;
  }

  if (command === 'buy') {
    const itemName = args.join(' ').toLowerCase();
    const item = SHOP_ITEMS.find(i => i.name.toLowerCase().includes(itemName));
    if (!item) {
      await sock.sendMessage(dest, { text: '❌ Item not found. Check `.market` for available items.' }, { quoted: message });
      return true;
    }
    if (user.wallet < item.price) {
      await sock.sendMessage(dest, { text: `❌ Not enough funds! You need ${formatMoney(item.price)} but have ${formatMoney(user.wallet)}.` }, { quoted: message });
      return true;
    }
    user.wallet -= item.price;
    const existing = user.inventory.find(i => i.item === item.name);
    if (existing) existing.qty += 1;
    else user.inventory.push({ item: item.name, qty: 1 });
    if (item.name === 'Bank Card') {
      user.bankLimit += 5000;
    }
    await user.save();
    await sock.sendMessage(dest, {
      text: `✅ Purchased *${item.name}* for ${formatMoney(item.price)}!\n💸 Wallet: ${formatMoney(user.wallet)}`,
    }, { quoted: message });
    return true;
  }

  if (command === 'sell') {
    const itemName = args.join(' ').toLowerCase();
    const idx = user.inventory.findIndex(i => i.item.toLowerCase().includes(itemName));
    if (idx === -1) {
      await sock.sendMessage(dest, { text: '❌ You don\'t have that item.' }, { quoted: message });
      return true;
    }
    const item = SHOP_ITEMS.find(i => i.name === user.inventory[idx].item);
    const sellPrice = item ? Math.floor(item.price * 0.5) : 50;
    user.inventory.splice(idx, 1);
    user.wallet += sellPrice;
    await user.save();
    await sock.sendMessage(dest, {
      text: `💸 Sold item for ${formatMoney(sellPrice)}!\n💸 Wallet: ${formatMoney(user.wallet)}`,
    }, { quoted: message });
    return true;
  }

  if (command === 'inventory' || command === 'inv') {
    if (user.inventory.length === 0) {
      await sock.sendMessage(dest, { text: '🎒 Your inventory is empty! Visit `.market` to shop.' }, { quoted: message });
      return true;
    }
    const list = user.inventory.map(i => `• ${i.item} x${i.qty}`).join('\n');
    await sock.sendMessage(dest, {
      text: `🎒 *${user.name}'s Inventory*\n\n${list}`,
    }, { quoted: message });
    return true;
  }

  if (command === 'gift') {
    const mentions = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const target = mentions[0];
    const itemName = args.slice(1).join(' ').toLowerCase();
    if (!target || !itemName) {
      await sock.sendMessage(dest, { text: '❌ Usage: `.gift @user <item>`' }, { quoted: message });
      return true;
    }
    const idx = user.inventory.findIndex(i => i.item.toLowerCase().includes(itemName));
    if (idx === -1) {
      await sock.sendMessage(dest, { text: '❌ You don\'t have that item.' }, { quoted: message });
      return true;
    }
    const itemObj = user.inventory[idx];
    user.inventory.splice(idx, 1);
    await user.save();
    const targetUser = await getOrCreateUser(target);
    const existing = targetUser.inventory.find(i => i.item === itemObj.item);
    if (existing) existing.qty += 1;
    else targetUser.inventory.push({ item: itemObj.item, qty: 1 });
    await targetUser.save();
    await sock.sendMessage(dest, {
      text: `🎁 You gifted *${itemObj.item}* to @${target.split('@')[0]}!`,
      mentions: [target],
    }, { quoted: message });
    return true;
  }

  if (command === 'topmoney') {
    const top = await User.find().sort({ wallet: -1 }).limit(10);
    const list = top.map((u, i) => `*${i + 1}.* ${u.name} — ${formatMoney(u.wallet)}`).join('\n');
    await sock.sendMessage(dest, { text: `💰 *Top Richest (Wallet)*\n\n${list}` }, { quoted: message });
    return true;
  }

  if (command === 'topbank') {
    const top = await User.find().sort({ bank: -1 }).limit(10);
    const list = top.map((u, i) => `*${i + 1}.* ${u.name} — ${formatMoney(u.bank)}`).join('\n');
    await sock.sendMessage(dest, { text: `🏦 *Top Richest (Bank)*\n\n${list}` }, { quoted: message });
    return true;
  }

  if (command === 'cooldowns' || command === 'cds') {
    const cdMap = user.cooldowns;
    const cdList = [];
    for (const [cmd, time] of cdMap.entries()) {
      const cdMs = config.COOLDOWNS[cmd] || 0;
      const left = (time.getTime() + cdMs) - Date.now();
      if (left > 0) cdList.push(`\`${cmd}\` | *${formatMs(left)}*`);
    }
    if (cdList.length === 0) {
      await sock.sendMessage(dest, { text: '✅ You have no active cooldowns!' }, { quoted: message });
      return true;
    }
    await sock.sendMessage(dest, {
      text: `*⏳ Your Active Cooldowns ⏳*\n${cdList.map(c => `* ${c}`).join('\n')}`,
    }, { quoted: message });
    return true;
  }

  if (command === 'rank') {
    const count = await User.countDocuments({ wallet: { $gt: user.wallet } });
    user.rank = count + 1;
    await user.save();
    await sock.sendMessage(dest, {
      text: `🏆 *Your Rank*\n\n👤 ${user.name}\n🏆 Rank: #${user.rank}\n💸 Wallet: ${formatMoney(user.wallet)}`,
    }, { quoted: message });
    return true;
  }

  if (command === 'xp') {
    await sock.sendMessage(dest, {
      text: `⚡ *XP Info*\n\n👤 ${user.name}\n📊 Level: ${user.level}\n⚡ XP: ${user.xp}/${user.level * 100}\n🏆 Rank: #${user.rank || '?'}`,
    }, { quoted: message });
    return true;
  }

  if (command === 'achievements') {
    const list = user.achievements.length ? user.achievements.map(a => `• ${a}`).join('\n') : 'No achievements yet!';
    await sock.sendMessage(dest, { text: `🔓 *Achievements*\n\n${list}` }, { quoted: message });
    return true;
  }

  if (command === 'quests') {
    const q = user.quests;
    if (!q || q.length === 0) {
      await sock.sendMessage(dest, { text: '📜 No active quests. Check back later!' }, { quoted: message });
    } else {
      const list = q.map(quest => `• *${quest.name}* — ${quest.progress}/${quest.goal} ${quest.completed ? '✅' : '⏳'}`).join('\n');
      await sock.sendMessage(dest, { text: `📜 *Active Quests*\n\n${list}` }, { quoted: message });
    }
    return true;
  }

  if (command === 'claim') {
    const cdLeft = await cdCheck(user, 'claim', dest, sock, message);
    if (cdLeft) return true;
    const completedQuests = user.quests.filter(q => q.completed && q.reward);
    if (completedQuests.length === 0) {
      await sock.sendMessage(dest, { text: '❌ No completed quests to claim!' }, { quoted: message });
      return true;
    }
    let total = 0;
    completedQuests.forEach(q => { total += q.reward; q.claimed = true; });
    user.wallet += total;
    user.quests = user.quests.filter(q => !q.claimed);
    user.setCooldown('claim');
    await user.save();
    await sock.sendMessage(dest, { text: `✅ Claimed ${formatMoney(total)} from completed quests!` }, { quoted: message });
    return true;
  }

  if (command === 'bonus') {
    const cdLeft = await cdCheck(user, 'bonus', dest, sock, message);
    if (cdLeft) return true;
    const amount = randomInt(100, 500);
    user.wallet += amount;
    user.setCooldown('bonus');
    await user.save();
    await sock.sendMessage(dest, {
      text: `🎁 *Bonus!* You received ${formatMoney(amount)}!\n💸 Wallet: ${formatMoney(user.wallet)}`,
    }, { quoted: message });
    return true;
  }

  if (command === 'bankupgrade') {
    const cost = 5000;
    if (user.wallet < cost) {
      await sock.sendMessage(dest, { text: `❌ You need ${formatMoney(cost)} to upgrade your bank limit.` }, { quoted: message });
      return true;
    }
    user.wallet -= cost;
    user.bankLimit += 5000;
    await user.save();
    await sock.sendMessage(dest, {
      text: `✅ Bank upgraded! New limit: ${formatMoney(user.bankLimit)}`,
    }, { quoted: message });
    return true;
  }

  if (command === 'upgrade') {
    await sock.sendMessage(dest, { text: `⬆️ *Upgrade Menu*\n\n• \`.bankupgrade\` — Increase bank limit by ${formatMoney(5000)} (costs ${formatMoney(5000)})` }, { quoted: message });
    return true;
  }

  if (command === 'prestige') {
    if (user.level < 50) {
      await sock.sendMessage(dest, { text: '❌ You need to be at least *Level 50* to prestige!' }, { quoted: message });
      return true;
    }
    user.rpg.prestige = (user.rpg.prestige || 0) + 1;
    user.level = 1;
    user.xp = 0;
    user.wallet = 500;
    user.bank = 0;
    user.inventory = [];
    await user.save();
    await sock.sendMessage(dest, {
      text: `⭐ *PRESTIGE ${user.rpg.prestige}!*\nYou have reset your progress and gained Prestige ${user.rpg.prestige}! You are now stronger than ever.`,
    }, { quoted: message });
    return true;
  }

  if (command === 'pet') {
    if (!user.pet.type) {
      await sock.sendMessage(dest, { text: '🥚 You don\'t have a pet! Buy a *Pet Egg* from `.market`.' }, { quoted: message });
    } else {
      await sock.sendMessage(dest, {
        text: `🐾 *Your Pet*\n\n🏷️ Name: ${user.pet.name || 'Unnamed'}\n🐉 Type: ${user.pet.type}\n📊 Level: ${user.pet.level}\n🍖 Hunger: ${user.pet.hunger}%\n⚡ XP: ${user.pet.xp}`,
      }, { quoted: message });
    }
    return true;
  }

  if (command === 'feedpet') {
    if (!user.pet.type) {
      await sock.sendMessage(dest, { text: '❌ You don\'t have a pet!' }, { quoted: message });
      return true;
    }
    user.pet.hunger = Math.min(100, (user.pet.hunger || 0) + 20);
    await user.save();
    await sock.sendMessage(dest, { text: `🍖 You fed ${user.pet.name || 'your pet'}! Hunger: ${user.pet.hunger}%` }, { quoted: message });
    return true;
  }

  if (command === 'trainpet') {
    if (!user.pet.type) {
      await sock.sendMessage(dest, { text: '❌ You don\'t have a pet!' }, { quoted: message });
      return true;
    }
    user.pet.xp = (user.pet.xp || 0) + 10;
    if (user.pet.xp >= user.pet.level * 50) {
      user.pet.level += 1;
      user.pet.xp = 0;
      await user.save();
      await sock.sendMessage(dest, { text: `🎉 ${user.pet.name || 'Your pet'} leveled up to level ${user.pet.level}!` }, { quoted: message });
    } else {
      await user.save();
      await sock.sendMessage(dest, { text: `💪 You trained ${user.pet.name || 'your pet'}! XP: ${user.pet.xp}/${user.pet.level * 50}` }, { quoted: message });
    }
    return true;
  }

  if (command === 'sellpet') {
    if (!user.pet.type) {
      await sock.sendMessage(dest, { text: '❌ You don\'t have a pet!' }, { quoted: message });
      return true;
    }
    const petValue = (user.pet.level || 1) * 500;
    user.wallet += petValue;
    user.pet = { name: null, type: null, level: 1, hunger: 100, xp: 0 };
    await user.save();
    await sock.sendMessage(dest, { text: `💸 You sold your pet for ${formatMoney(petValue)}!` }, { quoted: message });
    return true;
  }

  if (command === 'use') {
    const itemName = args.join(' ').toLowerCase();
    const idx = user.inventory.findIndex(i => i.item.toLowerCase().includes(itemName));
    if (idx === -1) {
      await sock.sendMessage(dest, { text: '❌ You don\'t have that item.' }, { quoted: message });
      return true;
    }
    const itemObj = user.inventory[idx];
    let effect = '';
    if (itemObj.item === 'Health Potion') {
      user.rpg.hp = Math.min(user.rpg.maxHp, (user.rpg.hp || 0) + 50);
      effect = `❤️ HP restored to ${user.rpg.hp}/${user.rpg.maxHp}`;
    } else if (itemObj.item === 'Lucky Charm') {
      effect = '🍀 Lucky Charm activated! Your luck is boosted for the next roll.';
    } else if (itemObj.item === 'Pet Egg') {
      const pets = ['🐉 Dragon', '🦊 Fox', '🐺 Wolf', '🐱 Cat', '🐶 Dog', '🦁 Lion'];
      const petType = pets[randomInt(0, pets.length - 1)];
      user.pet = { name: petType.split(' ')[1], type: petType, level: 1, hunger: 100, xp: 0 };
      effect = `🥚 The egg hatched! You got a ${petType}!`;
    } else {
      effect = `You used ${itemObj.item}!`;
    }
    if (itemObj.qty <= 1) user.inventory.splice(idx, 1);
    else itemObj.qty -= 1;
    await user.save();
    await sock.sendMessage(dest, { text: `✅ ${effect}` }, { quoted: message });
    return true;
  }

  return false;
}

module.exports = { handleEconomy };
